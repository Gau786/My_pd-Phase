﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Registration_page.Models
{
    public class User
    {
        public string Form_N0 { get; set; }
        public string FirstName { get; set; }
        public string Middle_Name { get; set; }
        public string Last_Name { get; set; }
        public string Account_type { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Branch { get; set; }
        public string Language { get; set; }
    }
}