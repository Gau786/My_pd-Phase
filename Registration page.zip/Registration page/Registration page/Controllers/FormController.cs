﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Registration_page.Models;

namespace Registration_page.Controllers
{
    public class FormController : Controller
    {
        //
        // GET: /Form/
        [HttpGet]
        public ActionResult Index()
        {
            var DBEntity = new CHN16_MMS98_TESTEntities1();
            List<formdetail> table=new List<formdetail>();
            foreach(var obj in DBEntity.formdetails)
            {
                var itm=new formdetail();
                itm.Form_N0=obj.Form_N0;
                itm.FirstName=obj.FirstName;
                itm.Middle_Name=obj.Middle_Name;
                itm.Last_Name=obj.Last_Name;
                itm.Account_type=obj.Account_type;
                itm.State=obj.State;
                itm.City=obj.City;
                itm.Branch=obj.Branch;
                itm.Language=obj.Language;
                table.Add(itm);
            }
            return View(table);
        }
        [HttpPost]
        public ActionResult Index(Registration_page.Models.User usermodel)
        {
            var db1 = new CHN16_MMS98_TESTEntities1();
            formdetail db = new formdetail();
            db.Form_N0 = usermodel.Form_N0;
            db.FirstName = usermodel.FirstName;
            db.Middle_Name = usermodel.Middle_Name;
            db.Last_Name = usermodel.Last_Name;
            db.Account_type = usermodel.Account_type;
            db.State = usermodel.State;
            db.City = usermodel.City;
            db.Branch = usermodel.Branch;
            db.Language = usermodel.Language;
            db1.formdetails.Add(db);
            db1.SaveChanges();
            return Json("Data Saved Successfully");
        }

    }
}
