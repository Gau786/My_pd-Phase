﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using Types;
using DAL;
using System.Data;

namespace BLL
{
    public class PatientBLL:IPatientBLL
    {
        public DataSet fillData()
        {
            IPatientDAL objView = new PatientDAL();
            return objView.fillData();
        }

        public int DeletePatient(string id)
        {
            IPatientDAL obj = new PatientDAL();
            return obj.DeletePatient(id);
        }

        

        public int PatientUpdate(string id, string name, string age)
        {
            IPatientDAL obj = new PatientDAL();
            return obj.PatientUpdate(id, name, age);
        }
    }
}
