﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using Types;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class PatientDAL:IPatientDAL
    {        
        static string str=ConfigurationManager.ConnectionStrings["grid"].ToString();
        SqlConnection con = new SqlConnection(str);
        
        public DataSet fillData()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tbl_Layer_Hospital", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "tbl_Layer_Hospital");
            return ds;
        }

        public int DeletePatient(string id)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from tbl_Layer_Hospital where id=@id", con);
            cmd.Parameters.Add(new SqlParameter("@id", id));
            int result=cmd.ExecuteNonQuery();
            if(result>0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            con.Close();
        }

        public int PatientUpdate(string id, string name, string age)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_update_hosp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@id", id));
            cmd.Parameters.Add(new SqlParameter("@name", name));
            cmd.Parameters.Add(new SqlParameter("@age", age));

            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res>0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            
        }
    }
}
