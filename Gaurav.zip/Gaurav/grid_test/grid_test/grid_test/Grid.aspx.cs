﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using BO;
using Types;
using DAL;
using System.Data;


namespace grid_test
{
    public partial class Grid : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IPatientBLL ob = new PatientBLL();
            DataSet ds = ob.fillData();

            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            IPatientBLL objBll = new PatientBLL();
            GridViewRow gridRow=GridView1.Rows[e.RowIndex];
            string id = ((Label)gridRow.FindControl("id")).Text;
            int Res = objBll.DeletePatient(id);
            if (Res == 1)
            {
                Response.Write("Deleted");
            }
            else
            {
                Response.Write("Wrong");
            }

            DataSet res = objBll.fillData();
            GridView1.DataSource = res;
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //GridViewRow gridView = GridView1.Rows[e.RowIndex];

            string id = GridView1.DataKeys[e.RowIndex].Value.ToString();
            string name = ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox1")).Text;
            string age= ((TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox2")).Text;


            //string id = ((Label)gridView.FindControl("id")).Text;
            //string name = ((TextBox)gridView.FindControl("TextBox1")).Text;
            //string age= ((TextBox)gridView.FindControl("TextBox2")).Text;

            IPatientBLL objUpdate = new PatientBLL();

            
            int result = objUpdate.PatientUpdate(id, name, age);
            if(result==1)
            {
                Response.Write("Updated");
            }
            else
            {
                Response.Write("Wrong");
            }

            //IPatientBLL objBllCancel = new PatientBLL();
            DataSet res = objUpdate.fillData();
            GridView1.DataSource = res;
            GridView1.DataBind();

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            IPatientBLL objBllEdit = new PatientBLL();
            DataSet res = objBllEdit.fillData();
            GridView1.DataSource = res;
            GridView1.DataBind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;

            IPatientBLL objBllCancel = new PatientBLL();
            DataSet res = objBllCancel.fillData();
            GridView1.DataSource = res;
            GridView1.DataBind();

        }
    }
}