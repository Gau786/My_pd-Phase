﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Types
{
    public interface IPatientDAL
    {
        DataSet fillData();
        int DeletePatient(string id);
        int PatientUpdate(string id, string name, string age);
    }
}
