﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Types
{
  public  interface IaddTicketbo
    {
      string TicketDesc { get; set; }
      string TicketType { get; set; }
      DateTime CurrDate { get; set; }
      string UserId { get; set; }
    }
}
