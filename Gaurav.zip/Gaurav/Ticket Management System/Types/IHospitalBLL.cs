﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;

namespace Types
{
    public interface IHospitalBLL
    {
        int patDelete(string id);
        DataSet viewGrid();
        int PatientUpdate(string id, string name, string age);
    }
}
