﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Types
{
   public interface Idal
    {
       int AddTicket(IaddTicketbo obja);
       string Login(Iloginbo objl);
       DataSet view(IaddTicketbo objv);
    }
}
