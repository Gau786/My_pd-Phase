﻿
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Types
{
    public interface IHospitalDAL
    {
        int patDelete(string id);
        DataSet viewGrid();
        int PatientUpdate(string id, string name, string age);
    }
}
