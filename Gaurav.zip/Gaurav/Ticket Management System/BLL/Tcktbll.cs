﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;
using DAL;
using System.Data;
using System.Data.SqlClient;

namespace BLL
{
    public class Tcktbll:Ibll
    {
        public int AddTicket(IaddTicketbo obja)
        {
            Idal objadd = new tckdal();
            return objadd.AddTicket(obja);
        }
        public DataSet view(IaddTicketbo objv)
        {
            Idal objview = new tckdal();
            return objview.view(objv);
        }
        public string Login(Iloginbo objl)
        {
            Idal objlo = new tckdal();
            return objlo.Login(objl);
        }
    }
}
