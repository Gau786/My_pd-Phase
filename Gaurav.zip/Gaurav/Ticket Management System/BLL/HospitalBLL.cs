﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using BO;
using DAL;
using Types;

namespace BLL
{
    public class HospitalBLL:IHospitalBLL
    {
        public int patDelete(string id)
        {
            IHospitalDAL obj = new HospitalDAL();
            return obj.patDelete(id);
        }

        public DataSet viewGrid()
        {

            IHospitalDAL obj = new HospitalDAL();
            return obj.viewGrid();
        }

        public int PatientUpdate(string id, string name, string age)
        {
            IHospitalDAL obj = new HospitalDAL();
            return obj.PatientUpdate(id, name, age);
        }

    }
}
