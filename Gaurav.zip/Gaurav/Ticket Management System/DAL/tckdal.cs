﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using BO;
using Types;

namespace DAL
{
    public class tckdal:Idal
    {
        string constr= "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user";
        int i = 0;
        
        public int AddTicket(IaddTicketbo obja)
        {
            SqlConnection cn = new SqlConnection(constr);
            try
            {
                
                cn.Open();
                SqlCommand cmd;
                cmd = new SqlCommand("pro_tck", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@TicketDesc", obja.TicketDesc));
                cmd.Parameters.Add(new SqlParameter("@TicketType", obja.TicketType));
                cmd.Parameters.Add(new SqlParameter("@Currdate", obja.CurrDate));
                cmd.Parameters.Add(new SqlParameter("@userid ", obja.UserId));

                int i = cmd.ExecuteNonQuery();
                cn.Close();
            }
            catch (SqlException sqex)
            {
                if (sqex.Message.Contains("PRIMARY KEY"))
                {
                    i = -2;
                }
                else
                    i = -1;

            }
            catch (Exception e)
            {
                i = -1;
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return i;



 
        }
        public DataSet view(IaddTicketbo objv)
        {
            SqlConnection cn = new SqlConnection(constr);
            try
            {
                
                //cn.Open();
                SqlCommand cmd;
                cmd = new SqlCommand("proc_view", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@userid", objv.UserId));

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds, "tbl_Ticket");
                return ds;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }

            }
            



        }
        public string Login(Iloginbo objl)
        {

            SqlConnection cn = new SqlConnection(constr);
            SqlCommand cmd;
            string ret=null;
            try
            {

                cn.Open();
                cmd = new SqlCommand("proc_log", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@userid", objl.UserId);
                cmd.Parameters.AddWithValue("@password", objl.Password);

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    return objl.UserId;
                }
                else
                    return null;
            }

            catch (Exception e)
            {
                return null;
            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
            }


            



        }
    }

}
