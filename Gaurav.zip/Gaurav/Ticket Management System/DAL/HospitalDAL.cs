﻿using System;
using System.Collections.Generic;
using BO;
using System.Data.SqlClient;
using System.Data;

using Types;
using System.Linq;
using System.Text;

namespace DAL
{
    public class HospitalDAL:IHospitalDAL
    {
        SqlConnection con = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN16_MMS98_TEST;User ID=mms98user;Password=mms98user");

        public DataSet viewGrid()
        {
            SqlCommand cmd = new SqlCommand("select * from tbl_Layer_Hospital", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "tbl_Layer_Hospital");
            return ds;
        }


        public int patDelete(string id)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from tbl_Layer_Hospital where id=@id", con);
            cmd.Parameters.Add(new SqlParameter("@id", id));
            int res = cmd.ExecuteNonQuery();
            con.Close();
            if(res>0)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }

        public int PatientUpdate(string id, string name, string age)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_update_hosp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@id", id));
            cmd.Parameters.Add(new SqlParameter("@name", name));
            cmd.Parameters.Add(new SqlParameter("@age", age));

            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }
    }
}
