﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using Types;
using BLL;
using BO;
using DAL;
namespace Ticket_Management_System
{
    public partial class Loginpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = Request.QueryString["name"];

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Loginbo objl=new Loginbo();
            objl.UserId = TextBox1.Text;
            objl.Password = TextBox2.Text;
            Ibll obj = new Tcktbll();
            string i = obj.Login(objl);
            Session["USER ID"] = TextBox1.Text;
            if (i == string.Empty)
            {
                Response.Write("Unauthorized user");
            }
            else
            {
                FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, true);
            }

        }
    }
}