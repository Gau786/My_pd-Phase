﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using Types;
using BLL;
using BO;
using DAL;

namespace Ticket_Management_System
{
    public partial class AddDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = "Welcome   " + Session["USER ID"];
            TextBox2.Text ="" + Session["USER ID"];

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Label3.Text == "Select Current Date")
            {
                Response.Write("Plz enter valid date");
            }
            else
            {

                AddTicketbo obja = new AddTicketbo();
                obja.TicketDesc = TextBox1.Text;
                obja.TicketType = DropDownList1.SelectedItem.Text;
                obja.CurrDate = Calendar1.SelectedDate.Date;
                obja.UserId = TextBox2.Text;
                
                Ibll obj = new Tcktbll();
                int i = obj.AddTicket(obja);
                if (i > 0)
                {
                    Response.Write("Insertion Successfully");
                }
                else
                    Response.Write("Insertion Failed");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("Login.aspx");
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            
            Label3.Text = Calendar1.SelectedDate.Date.ToString();
            string dt = DateTime.Now.Date.ToString();
            if (Label3.Text != dt)
            {
                Label3.Text = "Select Current Date";
            }


        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextBox3.Text = DropDownList1.SelectedValue;
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}