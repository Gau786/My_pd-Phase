﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Types;
using BLL;
using BO;
using DAL;
using System.Web.Security;


namespace Ticket_Management_System
{
    public partial class View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            IHospitalBLL ob = new HospitalBLL();
            DataSet ds= ob.viewGrid();

            GridView1.DataSource = ds;
            GridView1.DataBind();

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Response.Redirect("Login.aspx?name=gaurav");
        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            GridViewRow gridRow = GridView1.Rows[e.RowIndex];
            string id = ((Label)gridRow.FindControl("id")).Text;

            IHospitalBLL ob = new HospitalBLL();
            int res= ob.patDelete(id);
            if(res==1)
            {
                Response.Write("Deleted");
            }
            else
            {
                Response.Write("No");
            }


            IHospitalBLL ob1 = new HospitalBLL();
            DataSet ds = ob1.viewGrid();

            GridView1.DataSource = ds;
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            GridViewRow gridView = GridView1.Rows[e.RowIndex];
            string id = ((Label)gridView.FindControl("id")).Text;
            string name = ((TextBox)gridView.FindControl("TextBox1")).Text;
            string age = ((TextBox)gridView.FindControl("TextBox2")).Text;

            IHospitalBLL ob = new HospitalBLL();
            int result = ob.PatientUpdate(id, name, age);
            if (result == 1)
            {
                Response.Write("Updated");
            }
            else
            {
                Response.Write("Wrong");
            }

            DataSet res = ob.viewGrid();
            GridView1.DataSource = res;
            GridView1.DataBind();

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;

            IHospitalBLL ob = new HospitalBLL();
            DataSet ds = ob.viewGrid();

            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}