﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace BO
{
    public class HospitalBO:IHospitalBO
    {
        string id, name, age;

        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }
    }
}
