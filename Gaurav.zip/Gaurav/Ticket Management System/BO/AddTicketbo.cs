﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace BO
{
   public class AddTicketbo:IaddTicketbo
    {
       string ticketDesc;
      string ticketType;
      DateTime currDate;
      string userid;
      public string TicketDesc
      {
          get
          {
              return ticketDesc;
                  
          }
          set
          {
              ticketDesc = value;
          }
      }
      public string TicketType
      {
          get
          {
              return ticketType;
          }
          set
          {
              ticketType = value;
          }
      }
      public DateTime CurrDate
      {
          get
          {
              return currDate;
          }
          set
          {
             currDate = value;
          }
      }
      
      public string UserId
      {
          get
          {
              return userid;
          }
          set
          {
              userid = value;
          }
      }

       
       
    }
}
