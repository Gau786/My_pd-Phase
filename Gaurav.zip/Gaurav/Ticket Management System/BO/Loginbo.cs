﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace BO
{
    public class Loginbo:Iloginbo
    {
        string userid;
        string password;
        public string UserId
        {
            get 
            {
                return userid;
            }
            set
            {
                userid = value;
            }
        }
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
            }

        }
    }
}
